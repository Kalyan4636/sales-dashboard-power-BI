from PIL import Image, ImageDraw, ImageFont
import math

W, H = 1280, 720
img = Image.new("RGB", (W, H), "#E7E7EA")
draw = ImageDraw.Draw(img, "RGBA")

F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

def font(size, bold=False):
    return ImageFont.truetype(FB if bold else F, size)

def rrect(xy, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

def text(pos, s, size, color, bold=False, anchor=None):
    draw.text(pos, s, font=font(size, bold), fill=color, anchor=anchor)

# ---------- outer rounded container ----------
rrect([18, 18, 1262, 702], 30, fill="#F7F6F4")

# ---------- sidebar ----------
# draw as a rounded rect then square off the right edge by overlaying content bg
rrect([18, 18, 92, 702], 30, fill="#14141A")
draw.rectangle([56, 18, 92, 702], fill="#14141A")

nav_y = [190, 251, 311, 371, 432, 492, 552, 612]
labels = ["Overview", "Sales", "Regions", "Products", "Channels", "Customers", "Trends", "Reports"]
for i, y in enumerate(nav_y):
    cx = 55
    if i == 3:  # highlighted active item
        rrect([cx-19, y-19, cx+19, y+19], 12, fill="#EF5A44")
    else:
        draw.ellipse([cx-3, y-3, cx+3, y+3], fill="#5A5A62")
# avatar circle at bottom
draw.ellipse([55-19, 642-19, 55+19, 642+19], fill="#4B4B54")

# ---------- header ----------
text((118, 40), "Sales Performance Dashboard", 26, "#1C1C22", bold=True)
text((118, 74), "Outdoor & Sports Gear \u2014 European Retail | FY 2026", 14, "#8B8B93")
text((1242, 48), "Jan \u2013 Dec 2026", 13, "#8B8B93", anchor="ra")
text((1242, 68), "All Regions \u00b7 All Channels", 13, "#8B8B93", anchor="ra")

CARD = "#FFFFFF"
BORDER = (230, 230, 226, 255)
TITLE_COLOR = "#3A3A42"
SUB_COLOR = "#A9A9B0"
ACCENT = "#EF5A44"
ACCENT2 = "#2F6F9E"

# ============ TOP-LEFT: Revenue Trend chart ============
x0, y0, x1, y1 = 118, 115, 825, 375
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Monthly Revenue Trend", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "Total revenue by month, \u20ac", 11, SUB_COLOR)

months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
vals = [46,49,52,55,58,63,68,66,60,57,53,58]  # illustrative shape
plot_x0, plot_x1 = x0+30, x1-30
plot_y0, plot_y1 = y0+75, y1-45
n = len(vals)
step = (plot_x1 - plot_x0) / (n - 1)
maxv, minv = max(vals), min(vals)
pts = []
for i, v in enumerate(vals):
    px = plot_x0 + i*step
    py = plot_y1 - (v - minv) / (maxv - minv) * (plot_y1 - plot_y0)
    pts.append((px, py))
# gridlines
for gy in range(4):
    yy = plot_y0 + gy*(plot_y1-plot_y0)/3
    draw.line([(plot_x0, yy), (plot_x1, yy)], fill="#EFEFEC", width=1)
# area fill
poly = pts + [(plot_x1, plot_y1), (plot_x0, plot_y1)]
draw.polygon(poly, fill=(239, 90, 68, 30))
draw.line(pts, fill=ACCENT, width=3, joint="curve")
for (px, py) in pts:
    draw.ellipse([px-3, py-3, px+3, py+3], fill=ACCENT)
for i, m in enumerate(months):
    text((plot_x0 + i*step, plot_y1+14), m, 10, SUB_COLOR, anchor="ma")

# ============ TOP-RIGHT: Top Products list ============
x0, y0, x1, y1 = 845, 115, 1242, 453
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Top Products by Revenue", 16, TITLE_COLOR, bold=True)

top_products = [
    ("Summit Backpack 45L", 64909, 1.00),
    ("Alpine Tent 4P", 63708, 0.98),
    ("Trail Tent 2P", 62766, 0.97),
    ("Trail Boots", 60482, 0.93),
    ("Travel Backpack 35L", 52694, 0.81),
]
ly = y0 + 58
for name, rev, frac in top_products:
    draw.ellipse([x0+24, ly-16, x0+56, ly+16], fill="#DCDCE2")
    ic = name[0]
    text((x0+40, ly), ic, 13, "#6B6B73", bold=True, anchor="mm")
    text((x0+68, ly-22), name, 12, TITLE_COLOR, bold=True)
    bar_x0, bar_x1 = x0+68, x1-24
    bar_y = ly+2
    draw.line([(bar_x0, bar_y), (bar_x1, bar_y)], fill="#EDEDEA", width=6)
    draw.line([(bar_x0, bar_y), (bar_x0 + (bar_x1-bar_x0)*frac, bar_y)], fill=ACCENT2, width=6)
    text((x1-24, ly-22), f"\u20ac{rev:,.0f}", 11, SUB_COLOR, anchor="ra")
    ly += 65

# ============ BOTTOM-LEFT: Revenue by Region ============
x0, y0, x1, y1 = 118, 395, 461, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue by Region", 16, TITLE_COLOR, bold=True)

regions = [
    ("Western Europe", 198040),
    ("Central Europe", 191159),
    ("Northern Europe", 131489),
    ("Southern Europe", 124535),
]
colors = ["#EF5A44", "#2F6F9E", "#F2B84B", "#6FB07F"]
total = sum(v for _, v in regions)
cx, cy, r = x0 + 100, y0 + 155, 70
start = -90
for (name, v), c in zip(regions, colors):
    sweep = v/total*360
    draw.pieslice([cx-r, cy-r, cx+r, cy+r], start, start+sweep, fill=c)
    start += sweep
draw.ellipse([cx-40, cy-40, cx+40, cy+40], fill=CARD)
text((cx, cy), "\u20ac645K", 13, TITLE_COLOR, bold=True, anchor="mm")

ly = y0 + 100
lx = x0 + 200
for (name, v), c in zip(regions, colors):
    draw.ellipse([lx, ly-5, lx+10, ly+5], fill=c)
    text((lx+18, ly-9), name, 11, TITLE_COLOR)
    text((lx+18, ly+5), f"\u20ac{v:,.0f}", 10, SUB_COLOR)
    ly += 44

# ============ BOTTOM-MIDDLE: two KPI cards ============
x0, y0, x1, y1 = 480, 408, 808, 527
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+16), "TOTAL REVENUE", 12, SUB_COLOR, bold=True)
text((x0+24, y0+42), "\u20ac645,223", 32, "#1C1C22", bold=True)
text((x0+24, y0+86), "\u25b2 8.4% vs prior year", 12, "#3E9C63")

x0b, y0b, x1b, y1b = 480, 545, 808, 664
rrect([x0b, y0b, x1b, y1b], 18, fill=CARD, outline=BORDER, width=1)
text((x0b+24, y0b+16), "UNITS SOLD  \u00b7  GROSS MARGIN", 12, SUB_COLOR, bold=True)
text((x0b+24, y0b+42), "6,698", 26, "#1C1C22", bold=True)
text((x0b+180, y0b+42), "45.9%", 26, "#1C1C22", bold=True)
text((x0b+24, y0b+90), "units", 11, SUB_COLOR)
text((x0b+180, y0b+90), "margin", 11, SUB_COLOR)

# ============ BOTTOM-RIGHT: Sales by Channel ============
x0, y0, x1, y1 = 845, 473, 1242, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue by Sales Channel", 16, TITLE_COLOR, bold=True)

channels = [
    ("Online Store", 260307),
    ("Corporate", 179634),
    ("Retail Partners", 112447),
    ("Marketplace", 92836),
]
maxc = max(v for _, v in channels)
bx0 = x0 + 150
bx1 = x1 - 40
by = y0 + 70
bh = 20
row_h = (y1 - 20 - by) / len(channels)
ccolors = ["#EF5A44", "#2F6F9E", "#F2B84B", "#6FB07F"]
for (name, v), c in zip(channels, ccolors):
    text((x0+24, by+3), name, 12, TITLE_COLOR)
    w = (bx1-bx0) * v/maxc
    rrect([bx0, by-2, bx1, by+bh-2], 6, fill="#EFEFEC")
    rrect([bx0, by-2, bx0+w, by+bh-2], 6, fill=c)
    text((bx1, by+bh//2-2), f"\u20ac{v:,.0f}", 11, SUB_COLOR, anchor="rm")
    by += row_h

img.save("/mnt/user-data/outputs/powerbi_dashboard_background_1280x720.png")
print("saved")
