import subprocess, os

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FRAMES = 473  # ~15.77s at 30fps

items = [
    ("/mnt/user-data/outputs/powerbi_dashboard_background_1280x720.png",
     "PAGE 1  ·  Sales Performance Dashboard"),
    ("/mnt/user-data/outputs/powerbi_dashboard_background_page2_1280x720.png",
     "PAGE 2  ·  Product & Customer Insights"),
    ("/mnt/user-data/outputs/powerbi_dashboard_background_page3_1280x720.png",
     "PAGE 3  ·  Channel & Order Economics"),
    ("/mnt/user-data/outputs/powerbi_dashboard_background_page4_1280x720.png",
     "PAGE 4  ·  Product Deep Dive"),
]

os.makedirs("/home/claude/clips", exist_ok=True)

for i, (img, label) in enumerate(items):
    out = f"/home/claude/clips/clip{i}.mp4"
    label_esc = label.replace(":", "\\:").replace("'", "\\'")
    vf = (
        "scale=1280:720,"
        f"zoompan=z='min(zoom+0.00025,1.035)':d={FRAMES}:s=1280x720:fps=30,"
        "drawbox=x=0:y=636:w=1280:h=84:color=black@0.40:t=fill,"
        f"drawtext=fontfile={FONT}:text='{label_esc}':x=(w-text_w)/2:y=668:fontsize=25:fontcolor=white,"
        "format=yuv420p"
    )
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", img,
        "-vf", vf,
        "-frames:v", str(FRAMES),
        "-an", "-c:v", "libx264", "-crf", "18", "-preset", "medium",
        out,
    ]
    print("Running:", " ".join(cmd))
    subprocess.run(cmd, check=True)

print("done")
