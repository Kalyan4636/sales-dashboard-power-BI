from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 720
img = Image.new("RGB", (W, H), "#E7E7EA")
draw = ImageDraw.Draw(img, "RGBA")

F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

def font(size, bold=False):
    return ImageFont.truetype(FB if bold else F, size)

def rrect(xy, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

def text(pos, s, size, color, bold=False, anchor=None):
    draw.text(pos, s, font=font(size, bold), fill=color, anchor=anchor)

# ---------- outer rounded container ----------
rrect([18, 18, 1262, 702], 30, fill="#F7F6F4")

# ---------- sidebar (page 2 active = 3rd item: Regions) ----------
rrect([18, 18, 92, 702], 30, fill="#14141A")
draw.rectangle([56, 18, 92, 702], fill="#14141A")

nav_y = [190, 251, 311, 371, 432, 492, 552, 612]
for i, y in enumerate(nav_y):
    cx = 55
    if i == 2:  # highlighted active item -> "Regions / Products"
        rrect([cx-19, y-19, cx+19, y+19], 12, fill="#EF5A44")
    else:
        draw.ellipse([cx-3, y-3, cx+3, y+3], fill="#5A5A62")
draw.ellipse([55-19, 642-19, 55+19, 642+19], fill="#4B4B54")

# ---------- header ----------
text((118, 40), "Product & Customer Insights", 26, "#1C1C22", bold=True)
text((118, 74), "Outdoor & Sports Gear \u2014 European Retail | FY 2026", 14, "#8B8B93")
text((1242, 48), "Jan \u2013 Dec 2026", 13, "#8B8B93", anchor="ra")
text((1242, 68), "All Regions \u00b7 All Channels", 13, "#8B8B93", anchor="ra")

CARD = "#FFFFFF"
BORDER = (230, 230, 226, 255)
TITLE_COLOR = "#3A3A42"
SUB_COLOR = "#A9A9B0"
ACCENT = "#EF5A44"
ACCENT2 = "#2F6F9E"
PALETTE = ["#EF5A44", "#2F6F9E", "#F2B84B", "#6FB07F", "#9B7FC7"]

# ============ TOP-LEFT: Revenue by Country (horizontal bars) ============
x0, y0, x1, y1 = 118, 115, 825, 375
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Top Countries by Revenue", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "Revenue, \u20ac \u2014 top 8 markets", 11, SUB_COLOR)

countries = [
    ("United Kingdom", 74427),
    ("Germany", 70034),
    ("France", 55102),
    ("Italy", 50319),
    ("Spain", 46625),
    ("Netherlands", 42193),
    ("Poland", 40290),
    ("Sweden", 35978),
]
maxv = max(v for _, v in countries)
bx0 = x0 + 150
bx1 = x1 - 40
by = y0 + 68
row_h = (y1 - 16 - by) / len(countries)
bh = 16
for name, v in countries:
    text((x0+24, by+2), name, 12, TITLE_COLOR)
    w = (bx1 - bx0) * v / maxv
    rrect([bx0, by-1, bx1, by+bh-1], 5, fill="#EFEFEC")
    rrect([bx0, by-1, bx0+w, by+bh-1], 5, fill=ACCENT2)
    text((bx1, by+bh//2-1), f"\u20ac{v:,.0f}", 11, SUB_COLOR, anchor="rm")
    by += row_h

# ============ TOP-RIGHT: Category performance list ============
x0, y0, x1, y1 = 845, 115, 1242, 453
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Category Performance", 16, TITLE_COLOR, bold=True)
text((x1-24, y0+18), "Revenue \u00b7 units \u00b7 margin", 11, SUB_COLOR, anchor="ra")

categories = [
    ("Camping", 198505, 1270, 0.428),
    ("Hiking", 179959, 1598, 0.451),
    ("Travel", 123724, 1405, 0.477),
    ("Cycling", 87482, 1380, 0.489),
    ("Fitness", 55552, 1045, 0.512),
]
ly = y0 + 68
for i, (name, rev, units, margin) in enumerate(categories):
    c = PALETTE[i % len(PALETTE)]
    draw.ellipse([x0+24, ly-16, x0+56, ly+16], fill="#DCDCE2")
    text((x0+40, ly), name[0], 13, "#6B6B73", bold=True, anchor="mm")
    text((x0+68, ly-22), name, 12, TITLE_COLOR, bold=True)
    text((x0+68, ly+2), f"{units:,.0f} units \u00b7 {margin*100:.0f}% margin", 10, SUB_COLOR)
    text((x1-24, ly-10), f"\u20ac{rev:,.0f}", 12, TITLE_COLOR, bold=True, anchor="ra")
    ly += 54

# ============ BOTTOM-LEFT: Revenue by Customer Type ============
x0, y0, x1, y1 = 118, 395, 461, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue by Customer Type", 15, TITLE_COLOR, bold=True)

custtypes = [
    ("Returning", 226076),
    ("New", 215389),
    ("Business", 203758),
]
ccolors = ["#EF5A44", "#2F6F9E", "#F2B84B"]
total = sum(v for _, v in custtypes)
cx, cy, r = x0 + 100, y0 + 155, 70
start = -90
for (name, v), c in zip(custtypes, ccolors):
    sweep = v / total * 360
    draw.pieslice([cx-r, cy-r, cx+r, cy+r], start, start+sweep, fill=c)
    start += sweep
draw.ellipse([cx-40, cy-40, cx+40, cy+40], fill=CARD)
text((cx, cy), "\u20ac645K", 13, TITLE_COLOR, bold=True, anchor="mm")

ly = y0 + 110
lx = x0 + 200
for (name, v), c in zip(custtypes, ccolors):
    draw.ellipse([lx, ly-5, lx+10, ly+5], fill=c)
    text((lx+18, ly-9), name, 11, TITLE_COLOR)
    text((lx+18, ly+5), f"\u20ac{v:,.0f}", 10, SUB_COLOR)
    ly += 50

# ============ BOTTOM-MIDDLE: two KPI cards ============
x0, y0, x1, y1 = 480, 408, 808, 527
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+16), "TOP CATEGORY", 12, SUB_COLOR, bold=True)
text((x0+24, y0+42), "Camping", 28, "#1C1C22", bold=True)
text((x0+24, y0+86), "\u20ac198,505 revenue \u00b7 31% of total", 12, SUB_COLOR)

x0b, y0b, x1b, y1b = 480, 545, 808, 664
rrect([x0b, y0b, x1b, y1b], 18, fill=CARD, outline=BORDER, width=1)
text((x0b+24, y0b+16), "TOP MARKET", 12, SUB_COLOR, bold=True)
text((x0b+24, y0b+42), "United Kingdom", 24, "#1C1C22", bold=True)
text((x0b+24, y0b+86), "\u20ac74,427 revenue \u00b7 12% of total", 12, SUB_COLOR)

# ============ BOTTOM-RIGHT: Revenue by Quarter ============
x0, y0, x1, y1 = 845, 473, 1242, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue by Quarter", 16, TITLE_COLOR, bold=True)

quarters = [("Q1", 119436), ("Q2", 182428), ("Q3", 177661), ("Q4", 165698)]
maxq = max(v for _, v in quarters)
plot_x0, plot_x1 = x0 + 30, x1 - 30
plot_y0, plot_y1 = y0 + 60, y1 - 40
n = len(quarters)
gap = 30
bw = (plot_x1 - plot_x0 - gap*(n-1)) / n
for gy in range(4):
    yy = plot_y0 + gy*(plot_y1-plot_y0)/3
    draw.line([(plot_x0, yy), (plot_x1, yy)], fill="#EFEFEC", width=1)
for i, (q, v) in enumerate(quarters):
    bx = plot_x0 + i*(bw+gap)
    bh_ = (v/maxq) * (plot_y1-plot_y0)
    rrect([bx, plot_y1-bh_, bx+bw, plot_y1], 6, fill=ACCENT2)
    text((bx+bw/2, plot_y1-bh_-14), f"\u20ac{v/1000:.0f}K", 11, TITLE_COLOR, bold=True, anchor="ma")
    text((bx+bw/2, plot_y1+10), q, 12, SUB_COLOR, anchor="ma")

img.save("/mnt/user-data/outputs/powerbi_dashboard_background_page2_1280x720.png")
print("saved")
