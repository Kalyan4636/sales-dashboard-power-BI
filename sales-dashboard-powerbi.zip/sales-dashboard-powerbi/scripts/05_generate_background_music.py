import numpy as np
from scipy.io import wavfile

sr = 44100
dur = 63  # seconds, a bit longer than video for safety
t = np.linspace(0, dur, int(sr*dur), endpoint=False)

# Chord progression (Cmaj9 - Am9 - Fmaj7 - Gsus4), corporate ambient pad, 4 bars of ~7.5s each -> loop
freqs_chords = [
    [261.63, 329.63, 392.00, 493.88],  # Cmaj7-ish (C E G B)
    [220.00, 261.63, 329.63, 392.00],  # Am7 (A C E G)
    [174.61, 220.00, 261.63, 329.63],  # Fmaj7 (F A C E)
    [196.00, 246.94, 293.66, 392.00],  # Gsus-ish (G B D G) using D~293.66
]
bar_len = dur / 4.0

audio = np.zeros_like(t)

def envelope(local_t, bar_len):
    # slow attack, sustain, slow release across the bar
    a = 1.2
    r = 1.5
    env = np.ones_like(local_t)
    env = np.where(local_t < a, local_t/a, env)
    env = np.where(local_t > bar_len - r, np.clip((bar_len - local_t)/r, 0, 1), env)
    return np.clip(env, 0, 1)

for i, chord in enumerate(freqs_chords):
    start = i * bar_len
    end = start + bar_len
    mask = (t >= start) & (t < end)
    local_t = t[mask] - start
    env = envelope(local_t, bar_len)
    bar_audio = np.zeros_like(local_t)
    for f in chord:
        # soft pad: sine + a bit of triangle-ish harmonic, slight detune for warmth
        bar_audio += 0.5 * np.sin(2*np.pi*f*local_t)
        bar_audio += 0.15 * np.sin(2*np.pi*(f*1.003)*local_t)
        bar_audio += 0.10 * np.sin(2*np.pi*(f*2)*local_t)  # octave shimmer
    bar_audio *= env
    audio[mask] += bar_audio

# gentle sparkle: soft high arpeggio notes on top, sparse
rng = np.random.default_rng(7)
arp_notes = [523.25, 659.25, 783.99, 987.77, 880.0, 698.46]
note_len = 0.9
n_notes = int(dur / 1.5)
for k in range(n_notes):
    start = 2.0 + k*1.5 + rng.uniform(-0.1, 0.1)
    if start + note_len > dur:
        break
    f = arp_notes[k % len(arp_notes)]
    mask = (t >= start) & (t < start+note_len)
    local_t = t[mask] - start
    env = np.exp(-3.0*local_t) * np.clip(local_t/0.05, 0, 1)
    audio[mask] += 0.06 * np.sin(2*np.pi*f*local_t) * env

# normalize
audio = audio / (np.max(np.abs(audio)) + 1e-9) * 0.65

# overall fade in/out
fade_len = int(sr*2.5)
fade_in = np.linspace(0, 1, fade_len)
fade_out = np.linspace(1, 0, fade_len)
audio[:fade_len] *= fade_in
audio[-fade_len:] *= fade_out

stereo = np.stack([audio, audio*0.98], axis=1)
stereo_int16 = np.int16(np.clip(stereo, -1, 1) * 32767)
wavfile.write("/home/claude/bgmusic.wav", sr, stereo_int16)
print("music saved", stereo_int16.shape, stereo_int16.shape[0]/sr, "sec")
