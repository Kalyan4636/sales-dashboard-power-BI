from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 720
img = Image.new("RGB", (W, H), "#E7E7EA")
draw = ImageDraw.Draw(img, "RGBA")

F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

def font(size, bold=False):
    return ImageFont.truetype(FB if bold else F, size)

def rrect(xy, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

def text(pos, s, size, color, bold=False, anchor=None):
    draw.text(pos, s, font=font(size, bold), fill=color, anchor=anchor)

# ---------- outer rounded container ----------
rrect([18, 18, 1262, 702], 30, fill="#F7F6F4")

# ---------- sidebar (page 4 active = 4th item: Products) ----------
rrect([18, 18, 92, 702], 30, fill="#14141A")
draw.rectangle([56, 18, 92, 702], fill="#14141A")

nav_y = [190, 251, 311, 371, 432, 492, 552, 612]
for i, y in enumerate(nav_y):
    cx = 55
    if i == 3:  # highlighted active item -> "Products"
        rrect([cx-19, y-19, cx+19, y+19], 12, fill="#EF5A44")
    else:
        draw.ellipse([cx-3, y-3, cx+3, y+3], fill="#5A5A62")
draw.ellipse([55-19, 642-19, 55+19, 642+19], fill="#4B4B54")

# ---------- header ----------
text((118, 40), "Product Deep Dive", 26, "#1C1C22", bold=True)
text((118, 74), "Outdoor & Sports Gear \u2014 European Retail | FY 2026", 14, "#8B8B93")
text((1242, 48), "Jan \u2013 Dec 2026", 13, "#8B8B93", anchor="ra")
text((1242, 68), "20 SKUs \u00b7 5 categories", 13, "#8B8B93", anchor="ra")

CARD = "#FFFFFF"
BORDER = (230, 230, 226, 255)
TITLE_COLOR = "#3A3A42"
SUB_COLOR = "#A9A9B0"
ACCENT = "#EF5A44"
ACCENT2 = "#2F6F9E"
GOOD = "#3E9C63"
PALETTE = ["#EF5A44", "#2F6F9E", "#F2B84B", "#6FB07F", "#9B7FC7"]

# ============ TOP-LEFT: Top 5 vs Bottom 5 products ============
x0, y0, x1, y1 = 118, 115, 825, 375
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Best & Worst Selling Products", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "Revenue, \u20ac \u2014 top 5 vs. bottom 5 SKUs", 11, SUB_COLOR)

top5 = [
    ("Summit Backpack 45L", 64909),
    ("Alpine Tent 4P", 63708),
    ("Trail Tent 2P", 62766),
    ("Trail Boots", 60482),
    ("Travel Backpack 35L", 52694),
]
bottom5 = [
    ("Compact Repair Kit", 12941),
    ("Insulated Bottle", 12876),
    ("Training Mat", 11958),
    ("Resistance Band Set", 11726),
    ("Recovery Roller", 10264),
]
colw = (x1 - x0 - 24*3) / 2
colx0 = x0 + 24
colx1 = colx0 + colw + 24
text((colx0, y0+64), "TOP 5", 11, GOOD, bold=True)
text((colx1, y0+64), "BOTTOM 5", 11, "#C0554A", bold=True)

def mini_bars(colx, items, maxv, color):
    ly = y0 + 88
    bx1 = colx + colw
    for name, v in items:
        text((colx, ly-14), name, 10, TITLE_COLOR)
        w = colw * v/maxv
        rrect([colx, ly, colx+colw, ly+10], 4, fill="#EFEFEC")
        rrect([colx, ly, colx+w, ly+10], 4, fill=color)
        text((bx1, ly-14), f"\u20ac{v:,.0f}", 9, SUB_COLOR, anchor="ra")
        ly += 40

mini_bars(colx0, top5, 65000, GOOD)
mini_bars(colx1, bottom5, 65000, "#D9776D")

# ============ TOP-RIGHT: Avg price vs cost by category ============
x0, y0, x1, y1 = 845, 115, 1242, 453
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Avg. Price vs. Cost by Category", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "\u20ac per unit \u00b7 markup %", 11, SUB_COLOR)

cats = [
    ("Camping", 163.07, 86.14, 89.3),
    ("Hiking", 119.19, 61.32, 94.4),
    ("Travel", 87.11, 42.12, 106.8),
    ("Cycling", 67.20, 32.29, 108.1),
    ("Fitness", 56.12, 25.71, 118.3),
]
maxp = max(p for _, p, _, _ in cats)
bx0, bx1 = x0 + 130, x1 - 90
ly = y0 + 70
row_h = (y1 - 20 - ly) / len(cats)
for name, price, cost, markup in cats:
    text((x0+24, ly+2), name, 12, TITLE_COLOR)
    wp = (bx1-bx0) * price/maxp
    wc = (bx1-bx0) * cost/maxp
    rrect([bx0, ly-2, bx1, ly+14], 6, fill="#EFEFEC")
    rrect([bx0, ly-2, bx0+wp, ly+14], 6, fill=(47,111,158,90))
    rrect([bx0, ly-2, bx0+wc, ly+14], 6, fill=ACCENT2)
    text((x1-24, ly+2), f"+{markup:.0f}%", 11, GOOD, bold=True, anchor="ra")
    ly += row_h

lx = x0 + 24
ly2 = y1 - 18
draw.rectangle([lx, ly2-4, lx+10, ly2+6], fill=ACCENT2)
text((lx+16, ly2-9), "Avg. cost", 10, SUB_COLOR)
draw.rectangle([lx+90, ly2-4, lx+100, ly2+6], fill=(47,111,158,90))
text((lx+106, ly2-9), "Avg. price", 10, SUB_COLOR)

# ============ BOTTOM-LEFT: Revenue Concentration ============
x0, y0, x1, y1 = 118, 395, 461, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue Concentration", 15, TITLE_COLOR, bold=True)

segs = [("Top 5 SKUs", 0.472), ("Next 10 SKUs", 0.435), ("Bottom 5 SKUs", 0.093)]
scolors = ["#EF5A44", "#2F6F9E", "#DCDCE2"]
cx, cy, r = x0 + 100, y0 + 155, 70
start = -90
for (name, v), c in zip(segs, scolors):
    sweep = v * 360
    draw.pieslice([cx-r, cy-r, cx+r, cy+r], start, start+sweep, fill=c)
    start += sweep
draw.ellipse([cx-40, cy-40, cx+40, cy+40], fill=CARD)
text((cx, cy), "20 SKUs", 13, TITLE_COLOR, bold=True, anchor="mm")

ly = y0 + 110
lx = x0 + 200
for (name, v), c in zip(segs, scolors):
    draw.ellipse([lx, ly-5, lx+10, ly+5], fill=c)
    text((lx+18, ly-9), name, 11, TITLE_COLOR)
    text((lx+18, ly+5), f"{v*100:.1f}% of revenue", 10, SUB_COLOR)
    ly += 50

# ============ BOTTOM-MIDDLE: two KPI cards ============
x0, y0, x1, y1 = 480, 408, 808, 527
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+16), "BEST-SELLING PRODUCT", 12, SUB_COLOR, bold=True)
text((x0+24, y0+42), "Summit Backpack 45L", 20, "#1C1C22", bold=True)
text((x0+24, y0+80), "447 units \u00b7 \u20ac64,909 revenue", 12, SUB_COLOR)

x0b, y0b, x1b, y1b = 480, 545, 808, 664
rrect([x0b, y0b, x1b, y1b], 18, fill=CARD, outline=BORDER, width=1)
text((x0b+24, y0b+16), "ACTIVE SKUs  \u00b7  HIGHEST MARKUP", 12, SUB_COLOR, bold=True)
text((x0b+24, y0b+42), "20", 26, "#1C1C22", bold=True)
text((x0b+180, y0b+42), "Fitness", 22, "#1C1C22", bold=True)
text((x0b+24, y0b+90), "products", 11, SUB_COLOR)
text((x0b+180, y0b+90), "+118% markup", 11, SUB_COLOR)

# ============ BOTTOM-RIGHT: Units Sold by Category ============
x0, y0, x1, y1 = 845, 473, 1242, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Units Sold by Category", 16, TITLE_COLOR, bold=True)

unitcats = [("Hiking", 1598), ("Travel", 1405), ("Cycling", 1380), ("Camping", 1270), ("Fitness", 1045)]
maxu = max(v for _, v in unitcats)
plot_x0, plot_x1 = x0 + 30, x1 - 30
plot_y0, plot_y1 = y0 + 60, y1 - 40
n = len(unitcats)
gap = 20
bw = (plot_x1 - plot_x0 - gap*(n-1)) / n
avail_h = (plot_y1 - plot_y0) * 0.8
for i, (name, v) in enumerate(unitcats):
    bx = plot_x0 + i*(bw+gap)
    bh_ = (v/maxu) * avail_h
    c = PALETTE[i % len(PALETTE)]
    rrect([bx, plot_y1-bh_, bx+bw, plot_y1], 6, fill=c)
    text((bx+bw/2, plot_y1-bh_-16), f"{v:,}", 11, TITLE_COLOR, bold=True, anchor="ma")
    text((bx+bw/2, plot_y1+10), name, 10, SUB_COLOR, anchor="ma")

img.save("/mnt/user-data/outputs/powerbi_dashboard_background_page4_1280x720.png")
print("saved")
