from PIL import Image, ImageDraw, ImageFont

W, H = 1280, 720
img = Image.new("RGB", (W, H), "#E7E7EA")
draw = ImageDraw.Draw(img, "RGBA")

F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

def font(size, bold=False):
    return ImageFont.truetype(FB if bold else F, size)

def rrect(xy, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=r, fill=fill, outline=outline, width=width)

def text(pos, s, size, color, bold=False, anchor=None):
    draw.text(pos, s, font=font(size, bold), fill=color, anchor=anchor)

# ---------- outer rounded container ----------
rrect([18, 18, 1262, 702], 30, fill="#F7F6F4")

# ---------- sidebar (page 3 active = 5th item: Channels) ----------
rrect([18, 18, 92, 702], 30, fill="#14141A")
draw.rectangle([56, 18, 92, 702], fill="#14141A")

nav_y = [190, 251, 311, 371, 432, 492, 552, 612]
for i, y in enumerate(nav_y):
    cx = 55
    if i == 4:  # highlighted active item -> "Channels"
        rrect([cx-19, y-19, cx+19, y+19], 12, fill="#EF5A44")
    else:
        draw.ellipse([cx-3, y-3, cx+3, y+3], fill="#5A5A62")
draw.ellipse([55-19, 642-19, 55+19, 642+19], fill="#4B4B54")

# ---------- header ----------
text((118, 40), "Channel & Order Economics", 26, "#1C1C22", bold=True)
text((118, 74), "Outdoor & Sports Gear \u2014 European Retail | FY 2026", 14, "#8B8B93")
text((1242, 48), "Jan \u2013 Dec 2026", 13, "#8B8B93", anchor="ra")
text((1242, 68), "All Regions \u00b7 All Channels", 13, "#8B8B93", anchor="ra")

CARD = "#FFFFFF"
BORDER = (230, 230, 226, 255)
TITLE_COLOR = "#3A3A42"
SUB_COLOR = "#A9A9B0"
ACCENT = "#EF5A44"
ACCENT2 = "#2F6F9E"
PALETTE = ["#EF5A44", "#2F6F9E", "#F2B84B", "#6FB07F"]

# ============ TOP-LEFT: Avg Order Value by Channel ============
x0, y0, x1, y1 = 118, 115, 825, 375
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Average Order Value by Channel", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "\u20ac per order \u00b7 order count", 11, SUB_COLOR)

channels = [
    ("Corporate", 683, 263),
    ("Online Store", 197, 1322),
    ("Retail Partners", 186, 606),
    ("Marketplace", 180, 516),
]
maxv = max(v for _, v, _ in channels)
plot_x0, plot_x1 = x0 + 30, x1 - 30
plot_y0, plot_y1 = y0 + 95, y1 - 45
n = len(channels)
gap = 50
bw = (plot_x1 - plot_x0 - gap*(n-1)) / n
for gy in range(4):
    yy = plot_y0 + gy*(plot_y1-plot_y0)/3
    draw.line([(plot_x0, yy), (plot_x1, yy)], fill="#EFEFEC", width=1)
avail_h = (plot_y1 - plot_y0) * 0.78
for i, (name, aov, cnt) in enumerate(channels):
    bx = plot_x0 + i*(bw+gap)
    bh_ = (aov/maxv) * avail_h
    c = PALETTE[i % len(PALETTE)]
    rrect([bx, plot_y1-bh_, bx+bw, plot_y1], 6, fill=c)
    text((bx+bw/2, plot_y1-bh_-32), f"\u20ac{aov}", 13, TITLE_COLOR, bold=True, anchor="ma")
    text((bx+bw/2, plot_y1-bh_-14), f"{cnt} orders", 9, SUB_COLOR, anchor="ma")
    text((bx+bw/2, plot_y1+10), name, 11, SUB_COLOR, anchor="ma")

# ============ TOP-RIGHT: Revenue, COGS & Profit by Channel ============
x0, y0, x1, y1 = 845, 115, 1242, 453
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Revenue vs. Cost by Channel", 16, TITLE_COLOR, bold=True)
text((x0+24, y0+42), "Revenue \u00b7 COGS \u00b7 gross profit", 11, SUB_COLOR)

rows_data = [
    ("Online Store", 260307, 136974, 123333),
    ("Corporate", 179634, 104027, 75607),
    ("Retail Partners", 112447, 59012, 53435),
    ("Marketplace", 92836, 48826, 44010),
]
ly = y0 + 80
bar_x0 = x0 + 24
bar_x1 = x1 - 24
maxr = max(rev for _, rev, _, _ in rows_data)
for name, rev, cogs, profit in rows_data:
    text((x0+24, ly-20), name, 12, TITLE_COLOR, bold=True)
    text((x1-24, ly-20), f"\u20ac{rev:,.0f}", 11, SUB_COLOR, anchor="ra")
    total_w = (bar_x1 - bar_x0) * rev / maxr
    cogs_w = total_w * cogs / rev
    rrect([bar_x0, ly, bar_x0+total_w, ly+14], 5, fill="#EFEFEC")
    draw.rectangle([bar_x0, ly, bar_x0+cogs_w, ly+14], fill="#C9C9CE")
    draw.rectangle([bar_x0+cogs_w, ly, bar_x0+total_w, ly+14], fill=ACCENT2)
    ly += 54

lx = x0 + 24
ly2 = y1 - 26
draw.rectangle([lx, ly2-4, lx+10, ly2+6], fill="#C9C9CE")
text((lx+16, ly2-9), "COGS", 10, SUB_COLOR)
draw.rectangle([lx+80, ly2-4, lx+90, ly2+6], fill=ACCENT2)
text((lx+96, ly2-9), "Gross profit", 10, SUB_COLOR)

# ============ BOTTOM-LEFT: Average Discount ============
x0, y0, x1, y1 = 118, 395, 461, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Average Discount Rate", 15, TITLE_COLOR, bold=True)

pct = 0.0508
cx, cy, r = x0 + 172, y0 + 175, 85
draw.arc([cx-r, cy-r, cx+r, cy+r], 135, 405, fill="#EFEFEC", width=18)
sweep_end = 135 + 270*(pct/0.20)  # scaled so 20% = full ring for readability
draw.arc([cx-r, cy-r, cx+r, cy+r], 135, min(sweep_end, 405), fill=ACCENT, width=18)
text((cx, cy-6), f"{pct*100:.1f}%", 26, "#1C1C22", bold=True, anchor="mm")
text((cx, cy+20), "avg. discount", 11, SUB_COLOR, anchor="mm")
text((x0+24, y1-40), "Applied across 2,707 orders in FY 2026", 11, SUB_COLOR)

# ============ BOTTOM-MIDDLE: two KPI cards ============
x0, y0, x1, y1 = 480, 408, 808, 527
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+16), "TOTAL ORDERS", 12, SUB_COLOR, bold=True)
text((x0+24, y0+42), "2,707", 32, "#1C1C22", bold=True)
text((x0+24, y0+86), "across 4 sales channels", 12, SUB_COLOR)

x0b, y0b, x1b, y1b = 480, 545, 808, 664
rrect([x0b, y0b, x1b, y1b], 18, fill=CARD, outline=BORDER, width=1)
text((x0b+24, y0b+16), "AVG ORDER VALUE  \u00b7  TOP CHANNEL", 12, SUB_COLOR, bold=True)
text((x0b+24, y0b+42), "\u20ac238", 26, "#1C1C22", bold=True)
text((x0b+180, y0b+42), "Corporate", 22, "#1C1C22", bold=True)
text((x0b+24, y0b+90), "overall", 11, SUB_COLOR)
text((x0b+180, y0b+90), "by AOV (\u20ac683)", 11, SUB_COLOR)

# ============ BOTTOM-RIGHT: Orders share by Channel (donut) ============
x0, y0, x1, y1 = 845, 473, 1242, 681
rrect([x0, y0, x1, y1], 18, fill=CARD, outline=BORDER, width=1)
text((x0+24, y0+18), "Order Share by Channel", 16, TITLE_COLOR, bold=True)

shares = [
    ("Online Store", 1322),
    ("Retail Partners", 606),
    ("Marketplace", 516),
    ("Corporate", 263),
]
total = sum(v for _, v in shares)
cx, cy, r = x0 + 100, y0 + 145, 68
start = -90
for (name, v), c in zip(shares, PALETTE):
    sweep = v/total*360
    draw.pieslice([cx-r, cy-r, cx+r, cy+r], start, start+sweep, fill=c)
    start += sweep
draw.ellipse([cx-38, cy-38, cx+38, cy+38], fill=CARD)
text((cx, cy), "2,707", 13, TITLE_COLOR, bold=True, anchor="mm")
text((cx, cy+16), "orders", 10, SUB_COLOR, anchor="mm")

ly = y0 + 68
lx = x0 + 195
row_h = (y1 - 20 - ly) / len(shares)
for (name, v), c in zip(shares, PALETTE):
    draw.ellipse([lx, ly-4, lx+10, ly+6], fill=c)
    text((lx+18, ly-8), f"{name}  \u00b7  {v:,} orders  \u00b7  {v/total*100:.0f}%", 11, TITLE_COLOR)
    ly += row_h

img.save("/mnt/user-data/outputs/powerbi_dashboard_background_page3_1280x720.png")
print("saved")
